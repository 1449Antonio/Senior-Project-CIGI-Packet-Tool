# CAE-USF-Senior-Project

# Members
- Tommy
- Antonio
- Robert
- Zach
- Adrian

# Install Dependencies

1) If not already installed, install pip (preferred installer program).
2) 
```
pip install -r requirements.txt
```

## Running FE
```
npm run electron-dev
```

## Running BE
```
python3 frontend/backend/parsing/fileParse.py
```
